package com.edu.demo.service;

import java.util.List;

import com.edu.demo.entity.Student;
import com.edu.demo.error.StudentNotFoundException;

public interface StudentService {

	Student saveStudent(Student student);

	List<Student> fetchStudentList();

	Student updateStudent(Long sid, Student student);

	Student fetchStudentByName(String sname);

	Student fetchStudentById(Long sid) throws StudentNotFoundException;

	void deleteStudentById(Long sid);

	

}
