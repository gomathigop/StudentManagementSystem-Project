package com.edu.demo.service;

import java.util.List;

import com.edu.demo.entity.Course;
import com.edu.demo.error.CourseNotFoundException;

public interface CourseService {

	Course saveCourse(Course course);
	
	List<Course> fetchCourseList();
	
	Course updateCourse(Long cid, Course course);


	void deleteCourseById(Long cid);

	Course fetchCourseByName(String coursename);

	Course fetchCourseByFees(Double coursefees);

	Course fetchCourseById(Long cid) throws CourseNotFoundException;

	
}
